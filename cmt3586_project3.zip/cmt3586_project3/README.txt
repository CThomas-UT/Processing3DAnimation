Once the Program is started up there isn't much to do other than observe a stick figure representation of the classic matrix scene. There is some user interactivity available which is listed below:

Pressing 'U'
    pressing 'u' allows you to go up higher above the scene while still looking at neo, it creates a bit of a new perspective
Pressing 'D'
    pressing 'd' alternatively does the opposite. The camera shifts lower than originally and allows you to look from a lower angle at the scene. 